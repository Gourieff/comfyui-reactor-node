from .image import get_image
from .pickle_object import get_object
